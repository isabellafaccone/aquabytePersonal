#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include "stb_image.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "learnopengl/shader_m.h"
#include "learnopengl/camera.h"
#include "learnopengl/model.h"
#include <filesystem>
#include <iostream>
#include "ft2build.h"
#include "freetype/freetype.h"


void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);
void RenderText(Shader& shader, std::string text, float x, float y, float scale, glm::vec3 color);


// settings
const unsigned int SCR_WIDTH = 1080;
const unsigned int SCR_HEIGHT = 1080;
const unsigned int NUM_FSTOPS = 7;

// camera
Camera camera(glm::vec3(0.0f, 0.0f, 0.0f));
float lastX = SCR_WIDTH / 2.0f;
float lastY = SCR_HEIGHT / 2.0f;
bool firstMouse = true;
bool isMouseDown = false;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

// model transforms
float default_scale_fac = 0.05f;
float scale_fac = default_scale_fac;
float rotationY = -180.0f;
float translateZ = -40.0f;
double units2mm, length, width, height;
float fStops[NUM_FSTOPS] = { 1.4, 2.0, 2.8, 4.0, 5.6, 8.0, 11.0};

/// Holds all state information relevant to a character as loaded using FreeType
struct Character {
	unsigned int TextureID; // ID handle of the glyph texture
	glm::ivec2   Size;      // Size of glyph
	glm::ivec2   Bearing;   // Offset from baseline to left/top of glyph
	unsigned int Advance;   // Horizontal offset to advance to next glyph
};

struct FishSizes 
{
	float fishlength;
	float fishweight;
};

std::vector<FishSizes> fish;
std::map<GLchar, Character> Characters;
unsigned int VAO, VBO, selectedFish, defaultFish, selectedFStop;
Shader textShader, objShader;


GLFWwindow* initGL()
{
	// glfw: initialize and configure
// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Aquabyte Simulator", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);
	glfwSetMouseButtonCallback(window, mouse_button_callback);

	// tell GLFW to capture our mouse
	//glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return NULL;
	}

	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// compile and setup the shader
	// ----------------------------	
	textShader.Init("resources/text.vs", "resources/text.fs");
	objShader.Init("resources/model_loading.vs", "resources/model_loading.fs");

	glm::mat4 projection = glm::ortho(0.0f, static_cast<float>(SCR_WIDTH), 0.0f, static_cast<float>(SCR_HEIGHT));
	textShader.use();
	glUniformMatrix4fv(glGetUniformLocation(textShader.ID, "projection"), 1, GL_FALSE, glm::value_ptr(projection));

	// FreeType
	// --------
	FT_Library ft;
	// All functions return a value different than 0 whenever an error occurred
	if (FT_Init_FreeType(&ft))
	{
		std::cout << "ERROR::FREETYPE: Could not init FreeType Library" << std::endl;
		return NULL;
	}

	// find path to font
	std::string font_name = "resources/fonts/Antonio-Bold.ttf";
	if (font_name.empty())
	{
		std::cout << "ERROR::FREETYPE: Failed to load font_name" << std::endl;
		return NULL;
	}

	// load font as face
	FT_Face face;
	if (FT_New_Face(ft, font_name.c_str(), 0, &face)) {
		std::cout << "ERROR::FREETYPE: Failed to load font" << std::endl;
		return NULL;
	}
	else {
		// set size to load glyphs as
		FT_Set_Pixel_Sizes(face, 0, 48);

		// disable byte-alignment restriction
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		// load first 128 characters of ASCII set
		for (unsigned char c = 0; c < 128; c++)
		{
			// Load character glyph 
			if (FT_Load_Char(face, c, FT_LOAD_RENDER))
			{
				std::cout << "ERROR::FREETYTPE: Failed to load Glyph" << std::endl;
				continue;
			}
			// generate texture
			unsigned int texture;
			glGenTextures(1, &texture);
			glBindTexture(GL_TEXTURE_2D, texture);
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RED,
				face->glyph->bitmap.width,
				face->glyph->bitmap.rows,
				0,
				GL_RED,
				GL_UNSIGNED_BYTE,
				face->glyph->bitmap.buffer
			);
			// set texture options
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			// now store character for later use
			Character character = {
				texture,
				glm::ivec2(face->glyph->bitmap.width, face->glyph->bitmap.rows),
				glm::ivec2(face->glyph->bitmap_left, face->glyph->bitmap_top),
				static_cast<unsigned int>(face->glyph->advance.x)
			};
			Characters.insert(std::pair<char, Character>(c, character));
		}
		glBindTexture(GL_TEXTURE_2D, 0);
	}
	// destroy FreeType once we're finished
	FT_Done_Face(face);
	FT_Done_FreeType(ft);

	// configure VAO/VBO for texture quads
	// -----------------------------------
	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(float) * 6 * 4, NULL, GL_DYNAMIC_DRAW);
	glEnableVertexAttribArray(0);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 4 * sizeof(float), 0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindVertexArray(0);

	return window;
}

void renderObject(Model ourModel)
{
	objShader.use();

	// view/projection transformations
	glm::mat4 projection = glm::perspective(glm::radians(camera.Fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, (float)(camera.dofNear/units2mm), (float)(camera.dofFar/units2mm));
	glm::mat4 view = camera.GetViewMatrix();
	objShader.setMat4("projection", projection);
	objShader.setMat4("view", view);

	// render the loaded model
	glm::mat4 model = glm::mat4(1.0f);
	model = glm::translate(model, glm::vec3(0.0f, 0.0f, translateZ)); // translate it down so it's at the center of the scene
	model = glm::rotate(model, glm::radians(rotationY), glm::vec3(0, 1, 0)); // rotate it 
	model = glm::scale(model, glm::vec3(scale_fac, scale_fac, scale_fac));	// it's a bit too big for our scene, so scale it down
	objShader.setMat4("model", model);
	ourModel.Draw(objShader);

	// model parameters for nanosuit.obj
	//model = glm::translate(model, glm::vec3(0.0f, -4.0f, -10.0f)); // translate it down so it's at the center of the scene
	//model = glm::scale(model, glm::vec3(0.5f, 0.5f, 0.5f));	// it's a bit too big for our scene, so scale it down
}

void initFish()
{
	FishSizes fs;
	fs.fishlength = 80;
	fs.fishweight = 1;
	fish.push_back(fs);
	fs.fishlength = 190;
	fs.fishweight = 2;
	fish.push_back(fs);
	fs.fishlength = 300;
	fs.fishweight = 3;
	fish.push_back(fs);
	fs.fishlength = 410;
	fs.fishweight = 4;
	fish.push_back(fs);
	fs.fishlength = 520;
	fs.fishweight = 5;
	fish.push_back(fs);
	fs.fishlength = 630;
	fs.fishweight = 6;
	fish.push_back(fs);
	fs.fishlength = 740;
	fs.fishweight = 7;
	fish.push_back(fs);
	fs.fishlength = 850;
	fs.fishweight = 8;
	fish.push_back(fs);
	fs.fishlength = 960;
	fs.fishweight = 9;
	fish.push_back(fs);
	fs.fishlength = 1070;
	fs.fishweight = 10;
	fish.push_back(fs);
	fs.fishlength = 1180;
	fs.fishweight = 11;
	fish.push_back(fs);
	fs.fishlength = 1290;
	fs.fishweight = 12;
	fish.push_back(fs);
	selectedFish = 7;
	defaultFish = selectedFish;
}

void renderText()
{	
	// constants
	char txtbuf[1000];
	int inc = 20;
	int xinc = 400;
	int pos = SCR_HEIGHT - inc;	
	int posx = 10.0f;
	float text_scale = 0.4f;
	glm::vec3 text_color = glm::vec3(0.0, 1.0f, 0.0f);

	// render text
	sprintf(txtbuf, "Fish Length      %1.1fmm (%1.1fkg)", fish.at(selectedFish).fishlength, fish.at(selectedFish).fishweight);
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[-|+ with z | x]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Fish Distance   %1.1fmm", -(translateZ*units2mm));
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[-|+ with q | e]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Camera Focal Length  %1.1fmm (FOV %1.1f deg)", camera.RawFocalLength, camera.Fov);
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[-|+ focal length with f | r]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Camera Zoom   [%1.1fx]", camera.Zoom);
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[mouse wheel up | down]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Camera F/#   [%1.1f]", fStops[selectedFStop]);
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[-|+ with g | t]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Depth of Field  [%1.1fmm]", ((double)camera.dofFar- (double)camera.dofNear));
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[Near %1.1fmm, Far %1.1fmm]", camera.dofNear, camera.dofFar);
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Camera Position   [%1.1fmm,%1.1fmm,%1.1fmm]", (camera.Position[0] * units2mm), (camera.Position[1] * units2mm), (-camera.Position[2] * units2mm));
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[move left | right with a | d, up | down with w | s]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
	pos -= inc;
	sprintf(txtbuf, "Camera Orientation   [%1.1fdeg,%1.1fdeg] (Yaw, Pitch)", (double)camera.Yaw+90, camera.Pitch);
	RenderText(textShader, txtbuf, posx, pos, text_scale, text_color);
	sprintf(txtbuf, "[look around - left mouse button down and mouse move]");
	RenderText(textShader, txtbuf, posx + xinc, pos, text_scale, text_color);
}


int main()
{
	GLFWwindow* window = initGL();
	if (window == NULL)
		return -1;	

	initFish();

	// load models
	// -----------
	Model ourModel("resources/objects/fish/fish.obj");	
	printf("[%1.2f,%1.2f], [%1.2f,%1.2f], [%1.2f,%1.2f]\n", ourModel.extent.at(0), ourModel.extent.at(1), ourModel.extent.at(2), ourModel.extent.at(3), ourModel.extent.at(4), ourModel.extent.at(5));
	units2mm = fish.at(selectedFish).fishlength / (((double)ourModel.extent.at(1) - (double)ourModel.extent.at(0)) * default_scale_fac);
	length = ((double)ourModel.extent.at(1) - (double)ourModel.extent.at(0));
	width = ((double)ourModel.extent.at(3) - (double)ourModel.extent.at(2));
	height = ((double)ourModel.extent.at(5) - (double)ourModel.extent.at(4));
	printf("Length=%1.2f, Width=%1.2f, Height=%1.2f, mm/unit=%1.2f, sf=%1.4f\n", length * scale_fac, width * scale_fac, height * scale_fac, units2mm, scale_fac);	
	selectedFStop = 2;
	camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);

	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{
		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		renderObject(ourModel);
		renderText();
		
		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		camera.ProcessKeyboard(FORWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		camera.ProcessKeyboard(BACKWARD, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		camera.ProcessKeyboard(LEFT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		camera.ProcessKeyboard(RIGHT, deltaTime);
	if (glfwGetKey(window, GLFW_KEY_Z) == GLFW_PRESS)
	{		
		if (selectedFish > 0)
			selectedFish--;
		double new_sf = (double)fish.at(selectedFish).fishlength / fish.at(defaultFish).fishlength;
		scale_fac = new_sf * default_scale_fac;
		printf("Length=%1.2f, Width=%1.2f, Height=%1.2f, mm/unit=%1.2f, sf=%1.4f\n", length * scale_fac, width * scale_fac, height * scale_fac, units2mm, scale_fac);
	}
	if (glfwGetKey(window, GLFW_KEY_X) == GLFW_PRESS)
	{		
		if (selectedFish < fish.size() - 1)
			selectedFish++;
		double new_sf = (double)fish.at(selectedFish).fishlength / fish.at(defaultFish).fishlength;
		scale_fac = new_sf * default_scale_fac;
		printf("Length=%1.2f, Width=%1.2f, Height=%1.2f, mm/unit=%1.2f, sf=%1.4f\n", length * scale_fac, width * scale_fac, height * scale_fac, units2mm, scale_fac);
	}
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
	{
		translateZ++;
		camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
	}
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
	{
		translateZ--;
		camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
	}
	if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
	{
		camera.RawFocalLength++;
		camera.UpdateFOV();
		camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
	}
	if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS)
	{
		camera.RawFocalLength--;
		camera.UpdateFOV();
		camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
	}
	if (glfwGetKey(window, GLFW_KEY_T) == GLFW_PRESS)
	{
		if (selectedFStop< NUM_FSTOPS-1)
			selectedFStop++;
		camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
	}
	if (glfwGetKey(window, GLFW_KEY_G) == GLFW_PRESS)
	{
		if (selectedFStop > 0)
			selectedFStop--;
		camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
	}
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse button action occurs, this callback is called
void mouse_button_callback(GLFWwindow* window, int button, int action, int mods)
{
	if (button == GLFW_MOUSE_BUTTON_LEFT)
	{
		isMouseDown = !isMouseDown;
		firstMouse = true;
	}
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (isMouseDown == false)
		return;

	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top

	lastX = xpos;
	lastY = ypos;

	camera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	camera.ProcessMouseScroll(yoffset);
	camera.UpdateDOF(abs(translateZ * units2mm), fStops[selectedFStop]);
}

// render line of text
// -------------------
void RenderText(Shader& shader, std::string text, float x, float y, float scale, glm::vec3 color)
{
	// activate corresponding render state	
	shader.use();
	glUniform3f(glGetUniformLocation(shader.ID, "textColor"), color.x, color.y, color.z);
	glActiveTexture(GL_TEXTURE0);
	glBindVertexArray(VAO);

	// iterate through all characters
	std::string::const_iterator c;
	for (c = text.begin(); c != text.end(); c++)
	{
		Character ch = Characters[*c];

		float xpos = x + ch.Bearing.x * scale;
		float ypos = y - (ch.Size.y - ch.Bearing.y) * scale;

		float w = ch.Size.x * scale;
		float h = ch.Size.y * scale;
		// update VBO for each character
		float vertices[6][4] = {
			{ xpos,     ypos + h,   0.0f, 0.0f },
			{ xpos,     ypos,       0.0f, 1.0f },
			{ xpos + w, ypos,       1.0f, 1.0f },

			{ xpos,     ypos + h,   0.0f, 0.0f },
			{ xpos + w, ypos,       1.0f, 1.0f },
			{ xpos + w, ypos + h,   1.0f, 0.0f }
		};
		// render glyph texture over quad
		glBindTexture(GL_TEXTURE_2D, ch.TextureID);
		// update content of VBO memory
		glBindBuffer(GL_ARRAY_BUFFER, VBO);
		glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(vertices), vertices); // be sure to use glBufferSubData and not glBufferData

		glBindBuffer(GL_ARRAY_BUFFER, 0);
		// render quad
		glDrawArrays(GL_TRIANGLES, 0, 6);
		// now advance cursors for next glyph (note that advance is number of 1/64 pixels)
		x += (ch.Advance >> 6)* scale; // bitshift by 6 to get value in pixels (2^6 = 64 (divide amount of 1/64th pixels by 64 to get amount of pixels))
	}
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D, 0);
}